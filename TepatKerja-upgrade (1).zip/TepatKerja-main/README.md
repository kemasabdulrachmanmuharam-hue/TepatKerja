# TepatKerja

Aplikasi PWA pengingat waktu masuk kerja: hitung mundur jam berangkat, jadwal tetap harian,
sistem shift fleksibel, alarm bertahap, dan estimasi perjalanan berbasis lalu lintas & cuaca.

## Fitur utama

- **Jadwal**: pola mingguan, template shift, override per tanggal (cuti/izin/sakit/libur), rotasi bulanan.
- **Hitung mundur & alarm bertahap**: mulai bersiap, 15 menit sebelum berangkat, waktunya berangkat,
  dan 10 menit sebelum jam masuk, lengkap dengan tunda (snooze).
- **Notifikasi sistem** dengan tombol aksi **Tunda** dan **Sudah berangkat** (lewat Service Worker).
- **Perjalanan pintar**: Google Maps Platform untuk lalu lintas & cuaca, validasi titik berangkat dengan GPS.
- **Analitik ketepatan waktu**: tren 30 hari, ringkasan mingguan, streak, ekspor CSV.
- **Ekspor & berbagi jadwal**: file `.ics` untuk kalender, atau teks siap tempel ke WhatsApp.
- **Asisten AI** (Gemini) untuk briefing keberangkatan.
- **Akun & sinkronisasi** opsional lewat Firebase (Google Sign-In + Firestore).
- **PWA**: dapat dipasang, bekerja offline, dengan pintasan ke Dasbor, Jadwal, dan Alarm
  (`/?tab=dashboard`, `/?tab=schedule`, `/?tab=commute`).

## Menjalankan

Prasyarat: Node.js 22+ (atau Bun).

```bash
bun install        # atau: npm install
cp .env.example .env
bun run dev        # atau: npm run dev  → http://localhost:3000
```

### Variabel lingkungan

| Variabel | Fungsi |
| --- | --- |
| `GEMINI_API_KEY` | Briefing AI (`/api/coach/briefing`) |
| `GOOGLE_MAPS_API_KEY` | Lalu lintas, cuaca, dan geocoding (`/api/commute/*`) |
| `APP_URL` | URL publik aplikasi |
| `PORT` | Port server (bawaan 3000) |

Tanpa kunci di atas, aplikasi tetap berjalan; fitur terkait menampilkan pesan bahwa layanannya belum aktif.

## Skrip

| Perintah | Keterangan |
| --- | --- |
| `npm run dev` | Server Express + Vite (mode pengembangan) |
| `npm run build` | Build produksi ke `dist/` |
| `npm start` | Menjalankan server |
| `npm test` | Unit test utilitas (`node:test` via `tsx`) |
| `npm run typecheck` | Pemeriksaan tipe TypeScript (sama dengan `npm run lint`) |

## Struktur proyek

```
server.ts                Express: /api/health, /api/commute/*, /api/coach/briefing
src/App.tsx              Komponen akar, state, timer pengingat
src/components/          Tampilan (Dashboard, Jadwal, Perjalanan, Studio 3D, dsb.)
src/utils/               Logika murni yang diuji: jadwal, analitik, perjalanan, notifikasi
src/utils/*.test.ts      Unit test
public/sw-notify.js      Penanganan klik/aksi notifikasi di Service Worker
firestore.rules          Aturan keamanan Firestore (lihat security_spec.md)
```

## Catatan alarm & notifikasi

Aplikasi web tidak bisa menjamin alarm berbunyi saat aplikasi benar-benar ditutup. Pengingat berjalan
di dalam halaman/PWA yang aktif atau di latar belakang, dan notifikasi sistem ditampilkan lewat
Service Worker. Begitu aplikasi aktif kembali, jam langsung disegarkan sehingga pengingat yang
jatuh tempo tidak terlewat. Untuk pengingat yang andal meski aplikasi tertutup, diperlukan Web Push
dari server.

## Lisensi

Apache-2.0 (lihat header berkas sumber).
