# Changelog

## 1.1.0

### Performa & ukuran
- Menghapus video latar 4K (±28 MB) dari `public/assets`; diganti latar CSS di intro dan panel 3D.
- Memuat terpisah (lazy-load) komponen berat: scene three.js, grafik recharts, studio 3D,
  mode fokus Zen, dan panel akun.
- Service worker membersihkan cache lama otomatis (`cleanupOutdatedCaches`).

### Alarm & notifikasi
- Notifikasi pengingat kini lewat Service Worker. Sebelumnya `new Notification()` gagal diam-diam
  di Chrome Android sehingga notifikasi tidak pernah muncul di HP.
- Tombol aksi pada notifikasi: **Tunda** dan **Sudah berangkat**.
- Notifikasi memakai tag (tanpa duplikat), getar sesuai tahap, dan tetap tampil untuk tahap mendesak.
- Jam disegarkan seketika saat aplikasi kembali aktif (visibilitychange/focus/pageshow).

### Fitur baru
- **Bagikan Jadwal**: kirim jadwal 7 hari lewat menu bagikan perangkat atau salin ke clipboard.
- **Pintasan PWA** ke Dasbor, Jadwal, dan Alarm; tautan `?tab=` membuka tab langsung dan melewati intro.

### Kode, dependensi & dokumentasi
- README lengkap, CHANGELOG, nama paket `tepatkerja` dan versi 1.1.0.
- Skrip baru `npm test` dan `npm run typecheck`.
- 10 unit test baru (notifikasi, tautan pintas, teks bagikan jadwal); total 50 test.
- `.gitignore` mengabaikan `dev-dist/` (berkas hasil generate).
