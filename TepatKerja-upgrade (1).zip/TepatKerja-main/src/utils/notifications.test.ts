import test from 'node:test';
import assert from 'node:assert/strict';
import type { ActiveAlert } from '../types/schedule';
import {
  NOTIFICATION_ACTION_MESSAGE,
  buildReminderNotification,
  parseNotificationActionMessage,
} from './notifications';

function makeAlert(overrides: Partial<ActiveAlert> = {}): ActiveAlert {
  return {
    key: '2026-11-30__08:00__depart_now',
    occurrenceKey: '2026-11-30__08:00',
    stageId: 'depart_now',
    title: 'Waktunya Berangkat',
    message: 'Shift Pagi · Jam berangkat 07:10, jam masuk 08:00.',
    shiftName: 'Shift Pagi',
    departTimeStr: '07:10',
    checkInTimeStr: '08:00',
    ...overrides,
  };
}

test('buildReminderNotification: tahap berangkat punya aksi berangkat + tunda dan wajib interaksi', () => {
  const { title, options } = buildReminderNotification(makeAlert());
  assert.equal(title, 'Waktunya Berangkat');
  assert.equal(options.tag, 'tepatkerja-2026-11-30__08:00__depart_now');
  assert.equal(options.requireInteraction, true);
  assert.deepEqual(
    options.actions.map((a) => a.action),
    ['depart', 'snooze'],
  );
  assert.equal(options.data.alert.occurrenceKey, '2026-11-30__08:00');
});

test('buildReminderNotification: tahap bersiap hanya punya aksi tunda dan tidak wajib interaksi', () => {
  const { options } = buildReminderNotification(
    makeAlert({ stageId: 'prep_start' }),
  );
  assert.equal(options.requireInteraction, false);
  assert.deepEqual(
    options.actions.map((a) => a.action),
    ['snooze'],
  );
});

test('buildReminderNotification: tahap 10 menit sebelum masuk tidak menawarkan aksi berangkat', () => {
  const { options } = buildReminderNotification(
    makeAlert({ stageId: 'checkin_soon' }),
  );
  assert.equal(options.requireInteraction, true);
  assert.deepEqual(
    options.actions.map((a) => a.action),
    ['snooze'],
  );
});

test('parseNotificationActionMessage: menerima pesan valid', () => {
  const alert = makeAlert();
  const parsed = parseNotificationActionMessage({
    type: NOTIFICATION_ACTION_MESSAGE,
    action: 'snooze',
    alert,
  });
  assert.ok(parsed);
  assert.equal(parsed.action, 'snooze');
  assert.equal(parsed.alert.key, alert.key);
  assert.equal(parsed.alert.stageId, 'depart_now');
});

test('parseNotificationActionMessage: menolak pesan tidak valid', () => {
  const alert = makeAlert();
  assert.equal(parseNotificationActionMessage(null), null);
  assert.equal(parseNotificationActionMessage('halo'), null);
  assert.equal(
    parseNotificationActionMessage({ type: 'lain', action: 'snooze', alert }),
    null,
  );
  assert.equal(
    parseNotificationActionMessage({
      type: NOTIFICATION_ACTION_MESSAGE,
      action: 'hapus-semua',
      alert,
    }),
    null,
  );
  assert.equal(
    parseNotificationActionMessage({
      type: NOTIFICATION_ACTION_MESSAGE,
      action: 'snooze',
      alert: { ...alert, stageId: 'tahap_palsu' },
    }),
    null,
  );
  assert.equal(
    parseNotificationActionMessage({
      type: NOTIFICATION_ACTION_MESSAGE,
      action: 'depart',
      alert: { ...alert, key: '' },
    }),
    null,
  );
});
