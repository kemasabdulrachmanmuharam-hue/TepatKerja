import test from 'node:test';
import assert from 'node:assert/strict';
import { parseTabFromSearch, shouldSkipIntroForSearch } from './deepLink';

test('parseTabFromSearch: membaca tab valid dan mengabaikan yang tidak dikenal', () => {
  assert.equal(parseTabFromSearch('?tab=schedule'), 'schedule');
  assert.equal(parseTabFromSearch('?tab=commute&x=1'), 'commute');
  assert.equal(parseTabFromSearch('?tab=admin'), null);
  assert.equal(parseTabFromSearch(''), null);
});

test('shouldSkipIntroForSearch: lewati intro untuk autostart atau pintasan tab', () => {
  assert.equal(shouldSkipIntroForSearch('?autostart=1'), true);
  assert.equal(shouldSkipIntroForSearch('?tab=dashboard'), true);
  assert.equal(shouldSkipIntroForSearch('?tab=salah'), false);
  assert.equal(shouldSkipIntroForSearch(''), false);
});
