import type { AppTab } from '../types/schedule';

const VALID_TABS: readonly AppTab[] = [
  'dashboard',
  'studio3d',
  'schedule',
  'commute',
];

/** Membaca `?tab=` dari URL (dipakai pintasan PWA, mis. `/?tab=schedule`). */
export function parseTabFromSearch(search: string): AppTab | null {
  const value = new URLSearchParams(search).get('tab');
  return value && (VALID_TABS as readonly string[]).includes(value)
    ? (value as AppTab)
    : null;
}

/** Intro dilewati bila dibuka lewat `?autostart=1` atau pintasan tab langsung. */
export function shouldSkipIntroForSearch(search: string): boolean {
  return (
    new URLSearchParams(search).get('autostart') === '1' ||
    parseTabFromSearch(search) !== null
  );
}
