import type { ActiveAlert, ReminderStageId } from '../types/schedule';

/**
 * Notifikasi sistem untuk pengingat TepatKerja.
 *
 * Kenapa lewat Service Worker?
 * - Chrome Android (termasuk PWA terpasang) melempar error pada `new Notification()`,
 *   sehingga pengingat sebelumnya tidak pernah muncul di HP. `registration.showNotification()`
 *   adalah satu-satunya cara yang didukung di sana.
 * - Notifikasi dari Service Worker bisa membawa tombol aksi (Tunda / Sudah berangkat)
 *   yang ditangani oleh `public/sw-notify.js`.
 */

export const NOTIFICATION_ACTION_MESSAGE = 'tepatkerja-notification-action';

export type NotificationActionId = 'snooze' | 'depart' | 'open';

const VALID_ACTIONS: ReadonlySet<string> = new Set<NotificationActionId>([
  'snooze',
  'depart',
  'open',
]);

const VALID_STAGES: ReadonlySet<string> = new Set<ReminderStageId>([
  'prep_start',
  'depart_soon',
  'depart_now',
  'checkin_soon',
]);

export interface ReminderNotificationOptions {
  body: string;
  tag: string;
  icon: string;
  lang: string;
  renotify: boolean;
  requireInteraction: boolean;
  vibrate: number[];
  actions: Array<{ action: NotificationActionId; title: string }>;
  data: {
    url: string;
    alert: ActiveAlert;
  };
}

export interface ReminderNotificationPayload {
  title: string;
  options: ReminderNotificationOptions;
}

export interface NotificationActionMessage {
  type: typeof NOTIFICATION_ACTION_MESSAGE;
  action: NotificationActionId;
  alert: ActiveAlert;
}

const VIBRATION_BY_STAGE: Record<ReminderStageId, number[]> = {
  prep_start: [150],
  depart_soon: [200, 100, 200],
  depart_now: [400, 150, 400, 150, 400],
  checkin_soon: [300, 100, 300, 100, 300],
};

/** Menyusun isi notifikasi (murni, tanpa efek samping) agar mudah diuji. */
export function buildReminderNotification(
  alert: ActiveAlert,
): ReminderNotificationPayload {
  const canMarkDeparted =
    alert.stageId === 'depart_soon' || alert.stageId === 'depart_now';

  const actions: ReminderNotificationOptions['actions'] = [];
  if (canMarkDeparted) {
    actions.push({ action: 'depart', title: 'Sudah berangkat' });
  }
  actions.push({ action: 'snooze', title: 'Tunda' });

  return {
    title: alert.title,
    options: {
      body: alert.message,
      tag: `tepatkerja-${alert.key}`,
      icon: '/pwa-192x192.png',
      lang: 'id',
      renotify: true,
      requireInteraction:
        alert.stageId === 'depart_now' || alert.stageId === 'checkin_soon',
      vibrate: VIBRATION_BY_STAGE[alert.stageId],
      actions,
      data: { url: '/', alert },
    },
  };
}

function isNonEmptyString(value: unknown): value is string {
  return typeof value === 'string' && value.length > 0;
}

/** Memvalidasi pesan dari Service Worker sebelum dipercaya oleh aplikasi. */
export function parseNotificationActionMessage(
  data: unknown,
): NotificationActionMessage | null {
  if (!data || typeof data !== 'object') {
    return null;
  }
  const raw = data as Record<string, unknown>;
  if (raw.type !== NOTIFICATION_ACTION_MESSAGE) {
    return null;
  }
  if (typeof raw.action !== 'string' || !VALID_ACTIONS.has(raw.action)) {
    return null;
  }
  const alertRaw = raw.alert;
  if (!alertRaw || typeof alertRaw !== 'object') {
    return null;
  }
  const a = alertRaw as Record<string, unknown>;
  if (
    !isNonEmptyString(a.key) ||
    !isNonEmptyString(a.occurrenceKey) ||
    typeof a.stageId !== 'string' ||
    !VALID_STAGES.has(a.stageId) ||
    typeof a.title !== 'string' ||
    typeof a.message !== 'string' ||
    typeof a.shiftName !== 'string' ||
    typeof a.departTimeStr !== 'string' ||
    typeof a.checkInTimeStr !== 'string'
  ) {
    return null;
  }

  return {
    type: NOTIFICATION_ACTION_MESSAGE,
    action: raw.action as NotificationActionId,
    alert: {
      key: a.key,
      occurrenceKey: a.occurrenceKey,
      stageId: a.stageId as ReminderStageId,
      title: a.title,
      message: a.message,
      shiftName: a.shiftName,
      departTimeStr: a.departTimeStr,
      checkInTimeStr: a.checkInTimeStr,
      isSimulation: a.isSimulation === true ? true : undefined,
    },
  };
}

function waitForServiceWorker(
  timeoutMs: number,
): Promise<ServiceWorkerRegistration | null> {
  if (typeof navigator === 'undefined' || !('serviceWorker' in navigator)) {
    return Promise.resolve(null);
  }
  return new Promise((resolve) => {
    const timer = window.setTimeout(() => resolve(null), timeoutMs);
    navigator.serviceWorker.ready
      .then((registration) => {
        window.clearTimeout(timer);
        resolve(registration);
      })
      .catch(() => {
        window.clearTimeout(timer);
        resolve(null);
      });
  });
}

/**
 * Menampilkan notifikasi sistem untuk sebuah pengingat.
 * @returns true bila notifikasi berhasil ditampilkan.
 */
export async function showReminderNotification(
  alert: ActiveAlert,
): Promise<boolean> {
  if (
    typeof window === 'undefined' ||
    !('Notification' in window) ||
    Notification.permission !== 'granted'
  ) {
    return false;
  }

  const { title, options } = buildReminderNotification(alert);

  try {
    const registration = await waitForServiceWorker(1500);
    if (registration) {
      await registration.showNotification(
        title,
        options as unknown as NotificationOptions,
      );
      return true;
    }
  } catch {
    // lanjut ke fallback konstruktor Notification
  }

  try {
    new Notification(title, {
      body: options.body,
      tag: options.tag,
      icon: options.icon,
      lang: options.lang,
    });
    return true;
  } catch {
    return false;
  }
}

/** Mendengarkan klik tombol aksi pada notifikasi yang diteruskan Service Worker. */
export function subscribeToNotificationActions(
  handler: (action: NotificationActionId, alert: ActiveAlert) => void,
): () => void {
  if (typeof navigator === 'undefined' || !('serviceWorker' in navigator)) {
    return () => {};
  }
  const listener = (event: MessageEvent) => {
    const message = parseNotificationActionMessage(event.data);
    if (message) {
      handler(message.action, message.alert);
    }
  };
  navigator.serviceWorker.addEventListener('message', listener);
  return () => {
    navigator.serviceWorker.removeEventListener('message', listener);
  };
}
