import test from 'node:test';
import assert from 'node:assert/strict';
import { createDefaultState } from './storage';
import { getUpcomingWeekSchedule } from './scheduleEngine';
import { buildWeeklyShareText } from './shareSchedule';

test('buildWeeklyShareText: satu baris per hari dan penanda hari ini', () => {
  const state = createDefaultState();
  const now = new Date(2026, 10, 30, 6, 0, 0); // Senin, 30 Nov 2026
  const days = getUpcomingWeekSchedule(now, state, 7);
  const text = buildWeeklyShareText(days);
  const lines = text.split('\n');

  assert.match(lines[0], /^\*Jadwal Kerja 7 Hari ke Depan\* — TepatKerja$/);
  assert.equal(lines.length, 2 + 7); // header + baris kosong + 7 hari
  assert.match(lines[2], /^Senin, 30 Nov \(hari ini\): /);
});

test('buildWeeklyShareText: hari kerja memuat jam, hari libur memuat status', () => {
  const state = createDefaultState();
  const now = new Date(2026, 10, 30, 6, 0, 0);
  const days = getUpcomingWeekSchedule(now, state, 7);
  const text = buildWeeklyShareText(days);

  const working = days.filter((d) => d.occurrence);
  const off = days.filter((d) => !d.occurrence);
  assert.ok(working.length > 0, 'default state harus punya hari kerja');
  assert.match(text, /berangkat \d{2}:\d{2}, masuk \d{2}:\d{2}, pulang \d{2}:\d{2}/);
  if (off.length > 0) {
    assert.match(text, /: (Off|Libur|Cuti|Izin|Sakit)/);
  }
});

test('buildWeeklyShareText: daftar kosong tidak error', () => {
  assert.match(buildWeeklyShareText([]), /Belum ada jadwal\./);
});
