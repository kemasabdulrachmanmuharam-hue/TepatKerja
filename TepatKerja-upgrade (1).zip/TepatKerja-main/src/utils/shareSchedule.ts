import type { DaySchedulePreview } from '../types/schedule';
import { getNonWorkCategoryLabel } from './scheduleEngine';

/**
 * Menyusun teks jadwal yang rapi untuk dibagikan (WhatsApp, Telegram, catatan, dsb.).
 * Format `*tebal*` dipakai karena dikenali WhatsApp; di aplikasi lain tampil sebagai teks biasa.
 */
export function buildWeeklyShareText(days: DaySchedulePreview[]): string {
  const header = `*Jadwal Kerja ${days.length} Hari ke Depan* — TepatKerja`;
  if (days.length === 0) {
    return `${header}\nBelum ada jadwal.`;
  }

  const lines = days.map((day) => {
    const when = `${day.dayName}, ${day.dateShort}${day.isToday ? ' (hari ini)' : ''}`;
    const label = day.overrideLabel ? ` (${day.overrideLabel})` : '';

    if (day.occurrence) {
      const o = day.occurrence;
      const overnight = o.isOvernight ? ', lewat tengah malam' : '';
      return `${when}: ${o.shiftName} · berangkat ${o.jamBerangkatStr}, masuk ${o.jamMasukStr}, pulang ${o.jamPulangStr}${overnight}${label}`;
    }

    const status = getNonWorkCategoryLabel(
      day.kategoriStatus && day.kategoriStatus !== 'shift'
        ? day.kategoriStatus
        : 'off',
    );
    return `${when}: ${status}${label}`;
  });

  return [header, '', ...lines].join('\n');
}

export type ShareResult = 'shared' | 'copied' | 'cancelled' | 'failed';

/** Membagikan teks lewat Web Share API bila ada, kalau tidak disalin ke clipboard. */
export async function shareOrCopyText(
  text: string,
  title = 'Jadwal Kerja',
): Promise<ShareResult> {
  if (typeof navigator === 'undefined') {
    return 'failed';
  }

  if (typeof navigator.share === 'function') {
    try {
      await navigator.share({ title, text });
      return 'shared';
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        return 'cancelled';
      }
      // lanjut ke clipboard
    }
  }

  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return 'copied';
    }
  } catch {
    // clipboard ditolak
  }
  return 'failed';
}
