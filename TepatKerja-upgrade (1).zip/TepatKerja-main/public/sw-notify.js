/* TepatKerja — penanganan klik notifikasi pengingat.
 * Dimuat ke Service Worker hasil vite-plugin-pwa lewat `workbox.importScripts`.
 * Jangan memakai sintaks modul (import/export): file ini berjalan sebagai skrip klasik. */

var TK_ACTION_MESSAGE = 'tepatkerja-notification-action';

self.addEventListener('notificationclick', function (event) {
  var notification = event.notification;
  var data = (notification && notification.data) || {};
  var action = event.action || 'open';

  notification.close();

  event.waitUntil(
    (async function () {
      var windows = await self.clients.matchAll({
        type: 'window',
        includeUncontrolled: true,
      });

      // Pilih jendela yang paling relevan: yang sedang fokus, lalu yang terlihat.
      var target = null;
      for (var i = 0; i < windows.length; i += 1) {
        var candidate = windows[i];
        if (candidate.focused) {
          target = candidate;
          break;
        }
        if (!target && candidate.visibilityState === 'visible') {
          target = candidate;
        }
      }
      if (!target && windows.length > 0) {
        target = windows[0];
      }

      if (target) {
        if (action !== 'open' && data.alert) {
          target.postMessage({
            type: TK_ACTION_MESSAGE,
            action: action,
            alert: data.alert,
          });
        }
        try {
          await target.focus();
        } catch (err) {
          // fokus bisa ditolak oleh browser; pesan tetap sudah terkirim
        }
        return;
      }

      // Aplikasi tidak sedang terbuka: buka aplikasi.
      if (self.clients.openWindow) {
        await self.clients.openWindow(data.url || '/');
      }
    })(),
  );
});
